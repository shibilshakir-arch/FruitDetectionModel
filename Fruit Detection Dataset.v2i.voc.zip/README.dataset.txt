# Fruit Detection Dataset > 2022-09-27 9:16pm
https://universe.roboflow.com/ece4078-r3ymd/fruit-detection-dataset

Provided by a Roboflow user
License: CC BY 4.0

